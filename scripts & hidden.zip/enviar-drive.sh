#!/usr/bin/env bash
echo -e "\e[1;33m 
>>>>>>>>>>>>>>>>>>>>>>>> Enviando Documentos. <<<<<<>>><<<<<<<<<<<<<<<<
\e[0m "
rclone sync ~/Documents/ 'Google Drive':Documents -P -u --log-file=Logs/rclone-enviar.log --log-level INFO
if [[ $? -gt 0 ]] 
then
   echo -e "\e[1;31m  
>>>>>>>>>>>>>>>>>>>>>>>>> Documentos: Falhou. <<<<<<<<<<<<<<<<<<<<<<<<<
\e[0m    "
else
   rm -rf rm /home/pi/queue/*
   echo -e "\e[1;32m  
>>>>>>>>>>>>>>>>>>>>>>>> Documentos: Sucesso. <<<<<<<<<<<<<<<<<<<<<<<<<
\e[0m    "
fi

echo -e "\e[1;33m 
>>>>>>>>>>>>>>>>>>>>>>>>>> Enviando Imagens. <<<<<<>>><<<<<<<<<<<<<<<<<
\e[0m "
rclone sync ~/Images/ 'Google Drive':Images -P -u --log-file=Logs/rclone-enviar.log --log-level INFO
if [[ $? -gt 0 ]] 
then
   echo -e "\e[1;31m  
>>>>>>>>>>>>>>>>>>>>>>>>>>> Imagens: Falhou. <<<<<<<<<<<<<<<<<<<<<<<<<<
\e[0m    "
else
   rm -rf rm /home/pi/queue/*
   echo -e "\e[1;32m  
>>>>>>>>>>>>>>>>>>>>>>>>>> Imagens: Sucesso. <<<<<<<<<<<<<<<<<<<<<<<<<<
\e[0m    "
fi

echo -e "\e[1;34m 
Concluído em: $(date +%T). \e[0m"
echo " "
